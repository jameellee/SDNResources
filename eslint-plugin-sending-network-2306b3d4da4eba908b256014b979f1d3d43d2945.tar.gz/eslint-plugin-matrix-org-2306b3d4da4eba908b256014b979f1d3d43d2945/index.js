module.exports = {
    configs: {
        "babel": require("./babel"),
        "javascript": require("./javascript"),
        "react": require("./react"),
        "typescript": require("./typescript"),
    },
};
